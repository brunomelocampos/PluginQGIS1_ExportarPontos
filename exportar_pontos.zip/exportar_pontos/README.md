Cada linha do arquivo contém os seguintes campos separados por tabulação (`TAB`):

Nome Descrição X Y Z ou 
Nome Descrição Y X Z

> Exemplo:
> `Ponto A[TAB]Cerca[TAB]500000.123[TAB]7500000.456[TAB]100.000`

As colunas `Nome`, `Descrição` e `Z` são opcionais e só aparecem se forem selecionadas na interface.
Fonte de `Z` é confugurável assim como separador decimal("." ou ",") e arredondamento com casas decimais.